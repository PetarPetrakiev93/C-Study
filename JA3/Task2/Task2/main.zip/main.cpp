#include <string>
#include <iostream>

int main() {
	std::string input;
	std::cin >> input;
	int index = 0;
	std::string unique;
	while (index < input.size() - 6) {
		std::string temp = input.substr(index, 5);
		int counter = 0;
		for (int i = 0; i < input.size() - 2; i+=5) {
			if (input.substr(i, 5).compare(temp) == 0) {
				counter++;
			}
		}
		if (counter == 1) {
			unique = temp;
			break;
		}
		index += 5;
	}
	std::cout << unique << std::endl;
}